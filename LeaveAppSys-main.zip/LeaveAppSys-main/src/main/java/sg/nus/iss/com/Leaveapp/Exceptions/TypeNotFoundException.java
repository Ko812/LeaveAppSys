package sg.nus.iss.com.Leaveapp.Exceptions;

public class TypeNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TypeNotFoundException(String message) {
		super(message);
	}
	
	public TypeNotFoundException() {}
}
