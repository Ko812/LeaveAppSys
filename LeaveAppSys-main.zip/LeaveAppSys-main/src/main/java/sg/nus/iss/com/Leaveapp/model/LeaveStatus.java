package sg.nus.iss.com.Leaveapp.model;

public enum LeaveStatus {
  Applied, Cancelled, Approved, Rejected, Deleted
}
