package sg.nus.iss.com.Leaveapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
